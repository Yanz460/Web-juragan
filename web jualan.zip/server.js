const express = require('express');
const path = require('path');

const app = express();

// Serve file statis
app.use(express.static(path.join(__dirname, 'public')));

// Route utama
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

// WAJIB BUAT VERCEL: Export app, jangan pakai app.listen()
module.exports = app;